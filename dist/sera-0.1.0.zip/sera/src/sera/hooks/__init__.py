"""SERA lifecycle hooks package."""
