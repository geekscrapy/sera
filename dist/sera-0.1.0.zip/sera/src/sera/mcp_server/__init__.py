"""SERA MCP server package."""
