"""SERA CLI package."""
